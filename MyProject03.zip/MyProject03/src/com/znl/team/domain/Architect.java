package com.znl.team.domain;

public class Architect extends Designer{

    //stock 表示公司奖励的股票数量
    private int stock;

    public Architect() {

    }

    public Architect(int id, String name, int age, double salary, Equipment equipment, double bonus, int stock) {
        super(id, name, age, salary, equipment, bonus);
        this.stock = stock;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return getDetails()+"\t\t架构师\t\t"+getStatus()+"\t"+getBonus()+"\t\t"+ getStock()+"\t"+
                super.getEquipment().getDescription();
    }

    public String getDetailsForTeam(){
        return getMemberId()+"/"+getId()+"\t\t"+String.format("%-10s",getName())+getAge()+"\t\t"+getSalary()+"\t"+"\t\t架构师\t\t"+getStatus()+"\t"+getBonus()+"\t\t"+ getStock()+"\t"+
                super.getEquipment().getDescription();
    }
}
