package com.znl.team.domain;

public interface Equipment {

      String getDescription();
}
