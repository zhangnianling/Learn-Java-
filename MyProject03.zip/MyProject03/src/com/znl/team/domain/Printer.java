package com.znl.team.domain;

public class Printer implements Equipment{

    //model 表示机器的型号
    //display 表示显示器名称
    //type 表示机器的类型
    private String name;
    private String type;

    @Override
    public String getDescription() {
        return name+"("+type+")";
    }

    public Printer() {

    }

    public Printer(String name, String type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
