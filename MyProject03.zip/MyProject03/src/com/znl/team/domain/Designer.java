package com.znl.team.domain;

public class Designer extends Programmer{

    //bonus 表示奖金
    private double bonus;

    public Designer(int id, String name, int age, double salary, Equipment equipment, double bonus) {
        super(id, name, age, salary, equipment);
        this.bonus = bonus;
    }

    public Designer() {

    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }




    @Override
    public String toString() {
        return  getDetails()+"\t\t设计师\t\t"+getStatus()+"\t"+
                 + getBonus() +"\t\t\t\t"+super.getEquipment().getDescription();
    }

    public String getDetailsForTeam(){
        return getMemberId()+"/"+getId()+"\t\t"+String.format("%-10s",getName())+getAge()+"\t\t"+getSalary()+"\t"+"\t\t设计师\t\t"+getStatus()+"\t"+
                + getBonus() +"\t\t\t\t"+super.getEquipment().getDescription();
    }
}
