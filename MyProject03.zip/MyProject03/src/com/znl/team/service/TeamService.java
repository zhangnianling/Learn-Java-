package com.znl.team.service;

import com.sun.corba.se.spi.ior.iiop.IIOPFactories;
import com.znl.team.domain.Architect;
import com.znl.team.domain.Designer;
import com.znl.team.domain.Employee;
import com.znl.team.domain.Programmer;
import jdk.nashorn.internal.ir.IfNode;
import org.junit.experimental.theories.suppliers.TestedOn;
import sun.security.krb5.internal.crypto.Des;

public class TeamService {

    //counter为静态变量，用来为开发团队新增成员自动生成团队中的唯一ID，即memberId。（提示：应使用增1的方式）
    //MAX_MEMBER：表示开发团队最大成员数
    //team数组：用来保存当前团队中的各成员对象
    //total：记录团队成员的实际人数
    private int counter=1;
    private final int MAX_MEMBER=5;
    private Programmer[] team=new Programmer[MAX_MEMBER];
    private int total=0;

    public TeamService() {

    }

    public Programmer[] getTeam(){

        Programmer[] team = new Programmer[total];
        for (int i=0;i<team.length;i++){
            team[i]=this.team[i];
        }
        return team;
    }
    //失败信息包含以下几种：


    public void addMember(Employee e) throws TeamException{
        //  成员已满，无法添加
        if (total>MAX_MEMBER){
            throw new TeamException("成员已满，无法添加");
        }
        //  该成员不是开发人员，无法添加
        if (!(e instanceof Programmer)){
            throw new TeamException("该成员不是开发人员，无法添加");
        }
        //  该员工已在本开发团队中
        if (isExist(e)){
            throw new TeamException("该员工已在本开发团队中");
        }
        //  该员工已是某团队成员

        //  该员正在休假，无法添加
        Programmer p=(Programmer) e;//一定不会出现异常
        if ("BUSY".equals(p.getStatus().getNAME())){
            throw new TeamException("该员工已是某团队成员");
        }else if ("VOCATION".equals(p.getStatus().getNAME())){
            throw new TeamException("该员正在休假，无法添加");
        }
        //  团队中至多只能有一名架构师
        //  团队中至多只能有两名设计师
        //  团队中至多只能有三名程序员
        int numOfArch=0,numOfDes=0,numOfPro=0;
        for (int i=0;i<total;i++){
            if (team[i] instanceof Architect){
                numOfArch++;
            }else if (team[i] instanceof Designer){
                numOfDes++;
            }else if (team[i] instanceof Programmer){
                numOfPro++;
            }
        }

        if (p instanceof Architect){
            if (numOfArch>=1){
                throw new TeamException("团队中至多只能有一名架构师");
            }
        }else if (p instanceof Designer){
            if (numOfDes>=2){
                throw new TeamException("团队中至多只能有两名设计师");
            }
        }else if (p instanceof Programmer){
            if (numOfPro>=3){
                throw new TeamException("团队中至多只能有三名程序员");
            }
        }
        //将p加入现有team中
        team[total]=p;
        total++;
        //p的属性赋值
        p.setStatus(Status.BUSY);
        p.setMemberId(counter++);

    }
    //判断指定员工是否存在于开发团队中
    private boolean isExist(Employee e) {
        for (int i=0;i<total;i++){
            if (team[i].getId()==e.getId()){
                return true;
            }
        }
        return false;
    }
    //方法：从团队中删除成员
    //参数：待删除成员的memberId
    //异常：找不到指定memberId的员工，删除失败
    public void removeMember(int memberId)throws TeamException{
        int i=0;
        for (;i<total;i++){
            if (team[i].getMemberId()==memberId){
                team[i].setStatus(Status.FREE);
                break;
            }
        }

        if (i==total){
            throw new TeamException("找不到指定memberId的员工，删除失败");
        }

        for (int j=i;j<total;j++){
            team[j-1]=team[j];
        }
        team[total-1]=null;
        total--;


    }
}
